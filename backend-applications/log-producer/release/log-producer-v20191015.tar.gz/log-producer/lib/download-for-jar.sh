#!/bin/bash
#rm -rf ngaa-cdn-1.0.8-alpha.jar
wget http://103.235.226.139:9900/$1

